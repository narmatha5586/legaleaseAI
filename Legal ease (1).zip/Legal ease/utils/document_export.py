from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import os


def save_docx(content, filename):
    os.makedirs("outputs", exist_ok=True)

    filepath = os.path.join("outputs", filename)

    document = Document()
    document.add_heading("LegalEase - Legal Document", level=1)

    for paragraph in content.split("\n"):
        if paragraph.strip():
            document.add_paragraph(paragraph)

    document.save(filepath)

    return filepath


def save_pdf(content, filename):
    os.makedirs("outputs", exist_ok=True)

    filepath = os.path.join("outputs", filename)

    pdf = canvas.Canvas(filepath, pagesize=A4)

    width, height = A4
    y = height - 50

    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(50, y, "LegalEase - Legal Document")

    y -= 40

    pdf.setFont("Helvetica", 10)

    for line in content.split("\n"):
        if y < 50:
            pdf.showPage()
            pdf.setFont("Helvetica", 10)
            y = height - 50

        pdf.drawString(50, y, line[:100])
        y -= 15

    pdf.save()

    return filepath