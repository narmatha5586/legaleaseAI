import os
import time

from dotenv import load_dotenv
from google import genai
from google.genai.errors import ServerError, ClientError

# Load Gemini API key from .env
load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError(
        "GEMINI_API_KEY not found. Check your .env file."
    )

# Initialize Gemini client
client = genai.Client(api_key=api_key)

MODEL_NAME = "gemini-3.8-flash"


def generate_legal_document(document_type, details):

    prompt = f"""
You are an AI assistant for LegalEase,
an AI-powered legal document generator.

Create a professional draft of the following document.

Document Type: {document_type}

User Details:
{details}

Instructions:
1. Use clear, professional and formal language.
2. Organize the document with appropriate headings.
3. Include relevant clauses based on the details provided.
4. Do not invent names, dates or other missing information.
5. Use placeholders for missing required details.
6. Do not claim that the document is legally valid.
7. Clearly state that this is an AI-generated draft
   and requires review by a qualified legal professional.
"""

    max_attempts = 3

    for attempt in range(max_attempts):

        try:
            response = client.models.generate_content(
                model=MODEL_NAME,
                contents=prompt
            )

            if not response.text:
                raise ValueError(
                    "Gemini returned an empty response."
                )

            return response.text

        except ServerError as error:

            if error.code == 503:

                if attempt < max_attempts - 1:
                    wait_time = 5 * (attempt + 1)

                    print(
                        f"Gemini server busy. "
                        f"Retrying in {wait_time} seconds..."
                    )

                    time.sleep(wait_time)

                else:
                    raise RuntimeError(
                        "Gemini server is busy. "
                        "Please try again later."
                    ) from error

            else:
                raise

        except ClientError as error:
            raise RuntimeError(
                f"Gemini API request failed "
                f"(status {error.code}). "
                "Check your API key, model availability "
                "and API usage limits."
            ) from error