import streamlit as st
import requests


st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="centered"
)


st.title("⚖️ LegalEase")
st.subheader("AI-Powered Legal Document Generator")

st.write(
    "Create a draft legal document using AI."
)

document_type = st.selectbox(
    "Select Document Type",
    [
        "Rental Agreement",
        "Affidavit",
        "Leave and License Agreement",
        "Employment Agreement",
        "Legal Notice",
        "Complaint Letter",
        "Other"
    ]
)

details = st.text_area(
    "Enter the details",
    placeholder="Enter names, dates, address, purpose, terms and other required details..."
)

if st.button("Generate Document"):

    if not details.strip():
        st.warning("Please enter the document details.")
    else:
        with st.spinner("Generating document..."):

            try:
                response = requests.post(
                    "http://127.0.0.1:8000/generate",
                    json={
                        "document_type": document_type,
                        "details": details
                    }
                )

                if response.status_code == 200:

                    result = response.json()

                    st.success("Document generated successfully!")

                    st.text_area(
                        "Generated Legal Document",
                        result["document"],
                        height=500
                    )

                else:
                    st.error(
                        f"Server error: {response.status_code}"
                    )

            except Exception as e:
                st.error(
                    "Could not connect to the backend. "
                    "Please make sure the FastAPI server is running."
                )

st.info(
    "⚠️ This document is AI-generated and should be reviewed "
    "by a qualified legal professional before use."
)