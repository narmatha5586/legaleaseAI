from fastapi import APIRouter
from pydantic import BaseModel

from ai_core.gemini_generator import generate_legal_document

router = APIRouter()


class LegalDocumentRequest(BaseModel):
    document_type: str
    details: str


@router.post("/generate")
def generate_document(request: LegalDocumentRequest):

    document = generate_legal_document(
        request.document_type,
        request.details
    )

    return {
        "success": True,
        "document": document
    }